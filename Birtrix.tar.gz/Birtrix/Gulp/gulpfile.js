import * as nodePath from "path"
import gulp from "gulp"
import dartSass from 'sass'
import gulpSass from 'gulp-sass'
import cleanCss from 'gulp-clean-css'
import autoprefixer from 'gulp-autoprefixer'
import groupCssMediaQueries from 'gulp-group-css-media-queries'
import rename from 'gulp-rename'
import notify from "gulp-notify"
import plumber from "gulp-plumber"
import ifPlugin from "gulp-if"
import uglify from "gulp-uglify"

const isBuild = process.argv.includes("--build")
const pathCSS = ["./local/**/*.scss", "./local/**/.default/**/*.scss"]
// ["./local/**/*.scss", "./local/**/.**/*.scss"]
const pathJS = ["./local/**/*.js", "./local/**/.default/**/*.js"]
const sass = gulpSass(dartSass)



const scss = function () {
	return gulp.src(pathCSS, {
		sourcemaps: !isBuild,
		base: ".",
		dot: true
	})
		.pipe(plumber(
			notify.onError({
				title: 'SCSS',
				message: 'Error: <%= error.message %>'
			})
		))
		.pipe(sass({
			outputStyle: "expanded"
		}))
		.pipe(ifPlugin(
			isBuild,
			groupCssMediaQueries()
		))
		.pipe(autoprefixer({
			grid: true,
			overrideBrowserList: ['last 3 versions'],
			cascade: true
		}))
		.pipe(gulp.dest("./"))
		.pipe(ifPlugin(
			isBuild,
			cleanCss()
		))
		.pipe(rename({
			extname: '.min.css'
		}))
		.pipe(gulp.dest("./"))
}

const js = function (cb) {
	return gulp.src(pathJS, {
		sourcemaps: !isBuild,
		base: ".",
		dot: true
	})
		.pipe(plumber(
			notify.onError({
				title: 'JS',
				message: 'Error: <%= error.message %>'
			})
		))
		.pipe(ifPlugin(
			isBuild,
			uglify()
		))
		.pipe(ifPlugin(
			isBuild,
			rename({
				extname: '.min.js'
			})
		))
		.pipe(ifPlugin(
			isBuild,
			gulp.dest("./")
		))
}

function watcher() {
	gulp.watch(pathCSS, scss)
	gulp.watch(pathJS, js)
}

const dev = gulp.series(gulp.parallel(scss, js), watcher)
const build = gulp.parallel(scss, js)

export { dev }
export { build }

gulp.task("default", dev)